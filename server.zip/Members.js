const members = [
    {
        id: 1, 
        name: "Masroor",
        email : 'masroor@gmail.com',
        status: 'active'
    },
    {
        id: 2, 
        name: "Ahmed",
        email : 'ahmed@gmail.com',
        status: 'active'
    },
    {
        id: 3, 
        name: "Shaan",
        email : 'shaan@gmail.com',
        status: 'active'
    },
    
];
module.exports = members;